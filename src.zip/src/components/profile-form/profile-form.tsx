import ProfileFormStyles from './profile-form.module.css';
import {FC, useState, useRef, useEffect, ChangeEvent, FormEvent} from "react";
import {useSelector, useDispatch, /* RootStateOrAny */} from "react-redux";
/* import {sendUserData} from "../../services/actions/user"; */
import {Input, EmailInput, PasswordInput, Button} from "@ya.praktikum/react-developer-burger-ui-components";
import { useFormWithValidation } from "../hooks/hooks";
import LoginForm from "../login-form/login-form";

const ProfileForm: FC = () => {
  /* const userData = useSelector((state: RootStateOrAny) => state.userData.userData);
  const accessToken = useSelector((state: RootStateOrAny) => state.userData.accessToken); */
  /* const dispatch = useDispatch();

  const [nameValue, setNameValue] = useState("?");
  const [loginValue, setLoginValue] = useState("?");
  const [passwordValue, setPasswordValue] = useState("");
  const [isDataChanged, setIsDataChanged] = useState(false);
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  const emailInputRef = useRef<HTMLInputElement | null>(null);
  const passwordInputRef = useRef<HTMLInputElement | null>(null);

  const onNameClick = () => null !== nameInputRef.current && nameInputRef.current.focus();

  const onEmailClick = () => null !== emailInputRef.current && emailInputRef.current.focus();

  const onPasswordClick = () => null !== passwordInputRef.current && passwordInputRef.current.focus();

  const onNameChange = (evt: ChangeEvent<HTMLInputElement>) => {
    const value = evt.target.value
    setNameValue(value)
    /* value === userData.name ? setIsDataChanged(false) : setIsDataChanged(true) */
  /* }

  const onEmailChange = (evt: ChangeEvent<HTMLInputElement>) => {
    const value = evt.target.value
    setLoginValue(value) */
    /* value === userData.email ? setIsDataChanged(false) : setIsDataChanged(true) */
  /* } */

  /* const onPasswordChange = (evt: ChangeEvent<HTMLInputElement>) => {
    const value = evt.target.value
    setPasswordValue(value)
    value === passwordValue ? setIsDataChanged(false) : setIsDataChanged(true)
  }
 */
  /* const onSubmit = (evt: FormEvent<HTMLFormElement>) => {
    evt.preventDefault();
    dispatch(sendUserData(accessToken, nameValue, loginValue, passwordValue))
  } */

  /* const onCancelEditing = () => {
    setNameValue(userData.name)
    setLoginValue(userData.email)
    setPasswordValue('')
  }

  useEffect(() => {
    if (userData) {
      setLoginValue(userData.email);
      setNameValue(userData.name);
      setPasswordValue('');
    }
  }, [userData]); */
  const dispatch = useDispatch();
  const [isDataUserChange, setIsDataUserChange] = useState<boolean>(false);
  const { values, setValues, handleChange, isValidForm } = useFormWithValidation();
  const [requestFailedMessage, setRequestFailedMessage] = useState(null);
  const [requestSuccessMessage, setRequestSuccessMessage] = useState< boolean | null >(null);
  const { user, editUserRequest, editUserFailed } = useSelector((store: any) => store.user);


  function handleSubmit(evt: React.SyntheticEvent<HTMLElement>) {
    evt.preventDefault();
    // @ts-ignore
    dispatch(editUser(values))
      .unwrap()
      .then((res: any) => {
        setRequestSuccessMessage(true);
      })
      .catch((err: any) => {
        setRequestFailedMessage(err.message);
      });
  }

  const handleChangeInput = (evt: React.ChangeEvent<HTMLInputElement>) => {
    handleChange(evt);
    if (requestFailedMessage) {
      setRequestFailedMessage(null);
    }
    if (requestSuccessMessage) {
      setRequestSuccessMessage(false);
    }
  };

  useEffect(() => {
    setIsDataUserChange(
      values.name !== user.name ||
        values.email !== user.email ||
        Boolean(values.password)
    );
  }, [values, user]);

  useEffect(() => {
    values.name = user.name;
    values.email = user.email;
    values.password = "";
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  

  return (
    <LoginForm
      isValidForm={isValidForm}
      textButton="Сохранить"
      onSubmit={handleSubmit}
      buttonIsInvisible={!isDataUserChange}
    >
      <Input
        type={"text"}
        placeholder={"Имя"}
        onChange={handleChangeInput}
        icon="EditIcon"
        value={values.name || ""}
        name={"name"}
        error={false}
        errorText={"Ошибка"}
        size={"default"}
        extraClass="mb-6"
        required
      />
      <EmailInput
        onChange={handleChangeInput}
        value={values.email || ""}
        name={"email"}
        placeholder="Логин"
        isIcon={true}
        extraClass="mb-6"
        required
      />
      <PasswordInput
        onChange={handleChangeInput}
        value={values.password || ""}
        name={"password"}
        extraClass="mb-6"
        icon="EditIcon"
      />
      {/* {
        isDataChanged && (<div className={ProfileFormStyles.buttons_container}>
          <Button onClick={onCancelEditing} type="secondary" size="medium" htmlType={'button'}>
            Отмена
          </Button>
          <Button type="primary" size="medium" htmlType={'button'}>
            Сохранить
          </Button>
        </div>)
      } */}
    </LoginForm>
  );
}

export default ProfileForm;