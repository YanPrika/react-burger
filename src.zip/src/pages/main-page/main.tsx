import React, { useState, useEffect } from 'react';
import css from '../main-page/main.module.css';
import { AppHeader } from '../../components/app-header/app-header';
/* import { BurgerIngredients } from '../burger-ingredients/burger-ingredients';
import { BurgerConstructor } from '../burger-constructor/burger-constructor'; */
import { getIngredients } from '../../services/actions/ingredients';
import { useDispatch } from '../../components/hooks/hooks';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import Container from '../../components/container/container';
/* import Login from '../../pages/LoginPage/login';
import Page404 from '../../pages/404Page/not-found';
import { NavLink, Route, Routes } from 'react-router-dom'; */

export const Main = () => {

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getIngredients());
  }, [dispatch]);


  return (
    <div className={css.main_rect}>
      {/* <NavLink className={({isActive}) => isActive ? "active" : ""} to="/">Login</NavLink> */}
      
      {/* <Routes>
        <Route path="/" element={<Login />}/>
        <Route path="/login" element={<Login />}/>
        <Route path="*" element={<Page404 />}/>
      </Routes> */}

      {/* <AppHeader /> */}
      <DndProvider backend={HTML5Backend}>
        <Container />
      </DndProvider>
    </div>
  );
}

export default Main;