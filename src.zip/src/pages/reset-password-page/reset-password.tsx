import {FC, useState, useRef, useEffect, ChangeEvent, FormEvent} from "react";
import css from "./reset-password.module.css";
import { Link, useLocation } from "react-router-dom";
import { Input, Button, PasswordInput } from "@ya.praktikum/react-developer-burger-ui-components";
/* import { resetPassword, setForgotPasswordState } from "../../services/actions/user"; */
import {/* RootStateOrAny, */ useDispatch, useSelector} from 'react-redux';

const ResetPassword: FC = () => {
  
  return (
    <article className={css.wrapper}>
      <form className={css.form}>
        <h1
          className={`${css.title} text text_type_main-medium mb-6`}
        >
          Восстановление пароля
        </h1>
        <PasswordInput
          onChange={()=> console.log("eventClick")}
          value={"passwordValue"}
          name={"password"}
          //@ts-ignore
          placeholder={"Введите новый пароль"}
        />
        <div className="mb-6 mt-6">
          <Input
            type={"text"}
            placeholder={"Введите код из письма"}
            onChange={()=> console.log("eventClick")}
            value={"codeValue"}
            name={"e-mail"}
            error={false}
            errorText={"Ошибка"}
            size={"default"}
          />
        </div>
        <Button type="primary" size="medium" htmlType={"button"}>
          Сохранить
        </Button>
      </form>
      <p className="text text_type_main-default text_color_inactive">
        {"Вспомнили пароль? "}
        <Link className={css.link} to="/login">
          Войти
        </Link>
      </p>
    </article>
  );
};

export default ResetPassword;
