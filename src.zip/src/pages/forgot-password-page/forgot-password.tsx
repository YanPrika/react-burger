import {FC, useState, useRef, FormEvent} from "react";
import css from "./forgot-password.module.css";
import { Link } from "react-router-dom";
import { Input, Button } from "@ya.praktikum/react-developer-burger-ui-components";
/* import { forgotPassword, setForgotPasswordState } from "../../services/actions/user"; */
import { useDispatch } from 'react-redux';

const ForgotPassword:FC = () => {    
  
    const [emailValue, setEmailValue] = useState("");
    const inputRef = useRef(null);
    const dispatch = useDispatch();
    /* const history = useHistory(); */

    return (
      <article className={css.wrapper}>
        <form /* onSubmit={handleSubmit} */ className={css.form}>
          <h1 className={`${css.title} text text_type_main-medium mb-6`}>
            Восстановление пароля
          </h1>
          <div className="mb-6">
            <Input
              type={"text"}
              placeholder={"Укажите e-mail"}
              onChange={()=> console.log("eventClick")}
              value={"emailValue"}
              name={"e-mail"}
              error={false}
              errorText={"Ошибка"}
              size={"default"}
            />
          </div>
          <Button type="primary" size="medium" htmlType={"button"}>
            Восстановить
          </Button>
        </form>
        <p className="text text_type_main-default text_color_inactive">
          {"Вспомнили пароль? "}
          <Link className={css.link} to="/login">
            Войти
          </Link>
        </p>
      </article>
    );
  };
  
  export default ForgotPassword;