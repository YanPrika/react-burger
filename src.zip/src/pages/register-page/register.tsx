import {FC, useState, useRef, useEffect, ChangeEvent, FormEvent} from "react";
import css from "./register.module.css";
import { ROUTE_MAIN } from "../../utils/const";
import { Link, useNavigate } from "react-router-dom";
import LoginForm from "../../components/login-form/login-form";
import { Input, Button, EmailInput, PasswordInput } from "@ya.praktikum/react-developer-burger-ui-components";
/* import { registration } from "../../services/actions/user"; */
import {/* RootStateOrAny, */ useDispatch, useSelector} from 'react-redux';
import { useFormWithValidation } from "../../components/hooks/hooks";
import { onRegister } from "../../services/actions/users";

const Register: FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { values, handleChange, isValidForm } = useFormWithValidation();
  const [requestFailedMessage, setRequestFailedMessage] = useState(null);
  const { onRegisterFailed, onRegisterRequest } = useSelector((store: any) => store.user);

  function handleSubmit(evt: React.SyntheticEvent<HTMLElement>) {
    evt.preventDefault();
     // @ts-ignore
    dispatch(onRegister(values))
      .unwrap()
      .then(() => {
        navigate(ROUTE_MAIN);
      })
      .catch((err: any) => {
        setRequestFailedMessage(err.message);
      });
  }

  const handleChangeInput = (evt: React.ChangeEvent<HTMLInputElement>) => {
    handleChange(evt);
    if (requestFailedMessage) {
      setRequestFailedMessage(null);
    }
  };

  return (
    <article className={css.wrapper}>
      {/* <form className={css.form}>
        <h1 className={`${css.title} text text_type_main-medium`} >
          Регистрация
        </h1> */}
      <LoginForm
        title="Регистрация"
        isValidForm={isValidForm}
        textButton="Зарегистрироваться"
        onSubmit={handleSubmit}
      >
        <div className="mt-6 mb-6">
        <Input
          type={"text"}
          placeholder={"Имя"}
          onChange={handleChangeInput}
          value={values.name || ""}
          name={"name"}
          error={false}
          errorText={"Ошибка"}
          size={"default"}
          extraClass="mb-6"
          required
        />
        </div>
        <div className="mb-6">
        <EmailInput
          onChange={handleChangeInput}
          value={values.email || ""}
          name={"email"}
          placeholder="E-mail"
          isIcon={false}
          extraClass="mb-6"
          required
        />
        </div>
        <div className="mb-6">
        <PasswordInput
          onChange={handleChangeInput}
          value={values.password || ""}
          name={"password"}
          extraClass="mb-6"
          required
        />
        </div>
        {/* <Button onSubmit={handleSubmit} type="primary" size="medium" htmlType={"button"}>
          Зарегистрироваться
        </Button>
      </form> */}
      </LoginForm>
      <p className="text text_type_main-default text_color_inactive">
        {"Уже зарегистрированы? "}
        <Link className={css.link} to="/login">
          Войти
        </Link>
      </p>
    </article>
  );
};

export default Register;
