import React, { useState, useEffect } from 'react';
import css from '../app/app.module.css';
import { AppHeader } from '../app-header/app-header';
import { BurgerIngredients } from '../burger-ingredients/burger-ingredients';
import { BurgerConstructor } from '../burger-constructor/burger-constructor';
import { getIngredients } from '../../services/actions/ingredients';
import { useDispatch } from '../hooks/hooks';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import Container from '../container/container';
import { ProtectedRouteElement } from "../../components/protected-route";
import LoginPage from '../../pages/login-page/login';
import Page404 from '../../pages/404-page/not-found';
import Main from '../../pages/main-page/main';
import ForgotPassword from '../../pages/forgot-password-page/forgot-password';
import Profile from '../../pages/profile-page/profile';
import { NavLink, Route, Routes, BrowserRouter, useLocation, useNavigate,} from 'react-router-dom';
import Register from '../../pages/register-page/register';
import ResetPassword from '../../pages/reset-password-page/reset-password';
import ProfileForm from '../profile-form/profile-form';

export const App = () => {

  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  /* const { removeIngredientDetails } = selectedIngredientSlice.actions; */

  let background = location.state && location.state.background;

  return (
    <div className={css.main_rect}>

      <AppHeader />
      
      <Routes location={background || location}>
        <Route path="/" element={<Main />}/>
        <Route
            path="/login"
            element={
              <ProtectedRouteElement
                onlyUnAuth={false}
                element={<LoginPage />}
              />
            }
          />
        {/* <Route path="/login" element={<LoginPage />}/> */}
        <Route
            path="/profile"
            element={
              <ProtectedRouteElement
                onlyUnAuth={true}
                element={<Profile />}
              />
            }
          />
        {/* <Route path="/profile" element={<Profile />}/> */}
        <Route path="/profile-form" element={<ProfileForm />}/> 
        <Route path="/register" element={<Register />}/>
        <Route
            path="/forgot-password"
            element={
              <ProtectedRouteElement
                onlyUnAuth={false}
                element={<ForgotPassword />}
              />
            }
          />
        {/* <Route path="/forgot-password" element={<ForgotPassword />}/> */}
        <Route
            path="/reset-password"
            element={
              <ProtectedRouteElement
                onlyUnAuth={false}
                element={<ResetPassword />}
              />
            }
          />
        {/* <Route path="/reset-password" element={<ResetPassword />}/> */}        
        {/* <ProtectedRoute path="/profile">
          <Profile/>
        </ProtectedRoute> */}
        <Route path="*" element={<Page404 />}/>
      </Routes>

      {/* <AppHeader />
      <DndProvider backend={HTML5Backend}>
        <Container />
      </DndProvider> */}
    </div>
  );
}

export default App;